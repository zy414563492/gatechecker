from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views import generic
import json
from .models import Building, Gate, User
from django.core import serializers
from django.forms.models import model_to_dict


class IndexView(generic.View):
    def get(self, request):
        # get请求
        return HttpResponse('这是get请求')

    def post(self, request):
        # post请求
        return HttpResponse('这是post请求')

    def put(self, request):
        # 其他请求
        return HttpResponse('这是其他请求')


def apis(request):
    print("hello input")
    # p={"word":"data"}
    # 查看客户端发来的请求,前端的数据
    print("request.body={}".format(request.body))
    # 返回给客户端的数据
    result = "success"
    if request.method == "POST":
        print(request.POST)

    user_input = json.loads(str(request.body, 'utf-8'))

    # print(user_input['a'])

    output = int(user_input['a']) + int(user_input['b'])

    return JsonResponse({"status": 200, "msg": "OK", "data": output})


# POST: http://localhost:8000/gatechecker/get_gates
def get_gates(request):
    gate_dic = {'gate_list': []}
    gate_query = Gate.objects.all()
    for gate in gate_query:
        gate_dic['gate_list'].append(gate.obj_to_dic())
        print(gate.obj_to_dic())
    return HttpResponse(json.dumps(gate_dic), content_type="application/json")


# POST: http://localhost:8000/gatechecker/add_gate
# JSON例:
# {
#     "gate_id": "G1",
#     "name": "南正門",
#     "is_open": true
# }
def add_gate(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    gate_input = json.loads(str(request.body, 'utf-8'))
    print(gate_input)
    gate_id = gate_input['gate_id']
    name = gate_input['name']
    is_open = gate_input['is_open']

    print(gate_id, name, is_open)
    gate = Gate(gate_id=gate_id, name=name, is_open=is_open)
    print("gate:\n", gate)

    # データベースに書く
    gate.save()
    print("書き込み成功\n")

    return HttpResponse(json.dumps(gate.obj_to_dic()), content_type="application/json")


# POST: http://localhost:8000/gatechecker/update_gate
# JSON例:
# {
#     "gate_id": "G1",
#     "name": "南正門",
#     "is_open": false
# }
def update_gate(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    gate_input = json.loads(str(request.body, 'utf-8'))
    gate_id = gate_input['gate_id']
    name = gate_input['name']
    is_open = gate_input['is_open']

    gate = Gate.objects.get(gate_id=gate_id)
    gate.name = name
    gate.is_open = is_open

    print("gate:\n", gate)

    # データベースに書く
    gate.save()
    print("書き込み成功\n")

    return HttpResponse(json.dumps(gate.obj_to_dic()), content_type="application/json")


# POST: http://localhost:8000/gatechecker/remove_gate
# JSON例:
# {
#     "gate_id": "G1"
# }
def remove_gate(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    gate_id = json.loads(str(request.body, 'utf-8'))["gate_id"]
    gate = Gate.objects.get(gate_id=gate_id)
    print("gate:\n", gate)

    # データベースから削除する
    gate.delete()
    print("削除成功\n")

    return HttpResponse(json.dumps(gate.obj_to_dic()), content_type="application/json")


# POST: http://localhost:8000/gatechecker/get_buildings
def get_buildings(request):
    building_dic = {'building_list': []}
    building_query = Building.objects.all()
    for building in building_query:
        building_dic['building_list'].append(building.obj_to_dic())
        print(building.obj_to_dic())
    return HttpResponse(json.dumps(building_dic), content_type="application/json")


# POST: http://localhost:8000/gatechecker/add_building
# JSON例:
# {
#     "building_id": "B5",
#     "name": "Cross",
#     "location": "Sapporo"
#     "with_gate": "G5"
# }
def add_building(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    building_input = json.loads(str(request.body, 'utf-8'))
    building_id = building_input['building_id']
    name = building_input['name']
    location = building_input['location']
    with_gate = building_input['with_gate']

    gate = Gate.objects.get(gate_id=with_gate)
    print("gate: {}".format(gate))

    building = Building(building_id=building_id, name=name, location=location, with_gate=gate)
    print("building:\n", building)

    # データベースに書く
    building.save()
    print("書き込み成功\n")

    return HttpResponse(json.dumps(building.obj_to_dic()), content_type="application/json")


# POST: http://localhost:8000/gatechecker/update_building
# JSON例:
# {
#     "building_id": "B5",
#     "name": "Cross Hotel",
#     "location": "Sapporo"
#     "with_gate": "G5"
# }
def update_building(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    building_input = json.loads(str(request.body, 'utf-8'))
    building_id = building_input['building_id']
    name = building_input['name']
    location = building_input['location']
    with_gate = building_input['with_gate']

    building = Building.objects.get(building_id=building_id)
    building.name = name
    building.location = location
    gate = Gate.objects.get(gate_id=with_gate)
    building.with_gate = gate

    print("building:\n", building)

    # データベースに書く
    building.save()
    print("書き込み成功\n")

    return HttpResponse(json.dumps(building.obj_to_dic()), content_type="application/json")


# POST: http://localhost:8000/gatechecker/remove_building
# JSON例:
# {
#     "building_id": "B5"
# }
def remove_building(request):
    # frontendからのデータを表示する
    print("request.body={}".format(request.body))

    building_id = json.loads(str(request.body, 'utf-8'))["building_id"]
    building = Building.objects.get(building_id=building_id)
    print("building:\n", building)

    # データベースから削除する
    building.delete()
    print("削除成功\n")

    return HttpResponse(json.dumps(building.obj_to_dic()), content_type="application/json")


# # POST: http://localhost:8000/gatechecker/get_users
# def get_users(request):
#     user_dic = {'user_list': []}
#     user_query = User.objects.all()
#     for user in user_query:
#         user_dic['user_list'].append(user.obj_to_dic())
#         print(user.obj_to_dic())
#     return HttpResponse(json.dumps(user_dic), content_type="application/json")
#
#
# # POST: http://localhost:8000/gatechecker/add_user
# # JSON例:
# # {
# #     "user_id": "U001",
# #     "name": "Cross"
# #     "with_building": "B1"
# # }
# def add_user(request):
#     # frontendからのデータを表示する
#     print("request.body={}".format(request.body))
#
#     user_input = json.loads(str(request.body, 'utf-8'))
#     user_id = user_input['user_id']
#     name = user_input['name']
#     with_building = user_input['with_building']
#
#     building = Building.objects.get(building_id=with_building)
#     print("building: {}".format(building))
#
#     user = User(user_id=user_id, name=name, with_building=building)
#     print("user:\n", user)
#
#     # データベースに書く
#     user.save()
#     print("書き込み成功\n")
#
#     return HttpResponse(json.dumps(user.obj_to_dic()), content_type="application/json")



