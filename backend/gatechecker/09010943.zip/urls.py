from django.conf.urls import url, include
from django.urls import path
from . import views


urlpatterns = [
    # 下面是类视图名
    path('', views.IndexView.as_view(), name='index'),
    url(r'apis', views.apis, name='apis'),

    url(r'get_gates/$', views.get_gates, name='get_gates'),
    url(r'add_gate', views.add_gate, name='add_gate'),
    url(r'update_gate', views.update_gate, name='update_gate'),
    url(r'remove_gate', views.remove_gate, name='remove_gate'),

    url(r'get_buildings/$', views.get_buildings, name='get_buildings'),
    url(r'add_building', views.add_building, name='add_building'),
    url(r'update_building', views.update_building, name='update_building'),
    url(r'remove_building', views.remove_building, name='remove_building'),

    # url(r'get_users/$', views.get_users, name='get_users'),
    # url(r'add_user', views.add_user, name='add_user'),
    # url(r'update_user', views.update_user, name='update_user'),
    # url(r'remove_user', views.remove_user, name='remove_user'),
]
