from django.db import models


class Gate(models.Model):
    gate_id = models.CharField(max_length=20, primary_key=True)
    name = models.CharField(max_length=20)
    is_open = models.BooleanField(default=True)

    def __str__(self):
        return "gate_id: {}\nname: {}\nis_open: {}\n".format(self.gate_id, self.name, str(self.is_open))

    def obj_to_dic(self):
        return {"gate_id": self.gate_id, "name": self.name, "is_open": self.is_open}


class Building(models.Model):
    building_id = models.CharField(max_length=20)
    name = models.CharField(max_length=20)
    location = models.TextField(max_length=100)
    # with_gate = models.ForeignKey(Gate, on_delete=models.CASCADE, unique=True)
    with_gate = models.OneToOneField(
        Gate,
        on_delete=models.CASCADE,
        primary_key=True,
        to_field='gate_id',
        related_name='building'
    )

    def __str__(self):
        return "building_id: {}\nname: {}\nlocation: {}\n".format(self.building_id, self.name, self.location)

    def obj_to_dic(self):
        return {"building_id": self.building_id, "name": self.name, "location": self.location}


# class User(models.Model):
#     user_id = models.CharField(max_length=20)
#     name = models.CharField(max_length=20)
#     with_building = models.ForeignKey(
#         Building,
#         on_delete=models.CASCADE
#     )
#
#     def __str__(self):
#         return "user_id: {}\nname: {}\n".format(self.user_id, self.name)
#
#     def obj_to_dic(self):
#         return {"user_id": self.user_id, "name": self.name}


